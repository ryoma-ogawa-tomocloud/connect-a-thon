﻿<?xml version="1.0" encoding="utf-8"?>
<SerializableDictionary>
	<KeyValueOfStringString xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:xsd="http://www.w3.org/2001/XMLSchema">
		<Key>00000002</Key>
		<Value>1.2.840.10008.3.1.2.3.3</Value>
	</KeyValueOfStringString>
	<KeyValueOfStringString xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:xsd="http://www.w3.org/2001/XMLSchema">
		<Key>00000100</Key>
		<Value>320</Value>
	</KeyValueOfStringString>
	<KeyValueOfStringString xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:xsd="http://www.w3.org/2001/XMLSchema">
		<Key>00000110</Key>
		<Value>1</Value>
	</KeyValueOfStringString>
	<KeyValueOfStringString xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:xsd="http://www.w3.org/2001/XMLSchema">
		<Key>00000800</Key>
		<Value>1</Value>
	</KeyValueOfStringString>
	<KeyValueOfStringString xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:xsd="http://www.w3.org/2001/XMLSchema">
		<Key>00001000</Key>
		<Value>1.2.826.0.1.3680043.8.498.96159764487304213565501167659093703223</Value>
	</KeyValueOfStringString>
</SerializableDictionary>