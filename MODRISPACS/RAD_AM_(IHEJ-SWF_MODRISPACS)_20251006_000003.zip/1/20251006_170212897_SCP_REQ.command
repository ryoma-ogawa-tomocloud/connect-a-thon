﻿<?xml version="1.0" encoding="utf-8"?>
<SerializableDictionary>
	<KeyValueOfStringString xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:xsd="http://www.w3.org/2001/XMLSchema">
		<Key>00000002</Key>
		<Value>1.2.840.10008.5.1.4.31</Value>
	</KeyValueOfStringString>
	<KeyValueOfStringString xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:xsd="http://www.w3.org/2001/XMLSchema">
		<Key>00000100</Key>
		<Value>32</Value>
	</KeyValueOfStringString>
	<KeyValueOfStringString xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:xsd="http://www.w3.org/2001/XMLSchema">
		<Key>00000110</Key>
		<Value>1</Value>
	</KeyValueOfStringString>
	<KeyValueOfStringString xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:xsd="http://www.w3.org/2001/XMLSchema">
		<Key>00000700</Key>
		<Value>2</Value>
	</KeyValueOfStringString>
	<KeyValueOfStringString xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:xsd="http://www.w3.org/2001/XMLSchema">
		<Key>00000800</Key>
		<Value>1</Value>
	</KeyValueOfStringString>
</SerializableDictionary>