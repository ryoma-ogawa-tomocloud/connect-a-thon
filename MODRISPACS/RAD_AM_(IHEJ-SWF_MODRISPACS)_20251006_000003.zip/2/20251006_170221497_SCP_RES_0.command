﻿<?xml version="1.0" encoding="utf-8"?>
<SerializableDictionary>
	<KeyValueOfStringString xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:xsd="http://www.w3.org/2001/XMLSchema">
		<Key>00000002</Key>
		<Value>1.2.840.10008.5.1.4.1.1.7</Value>
	</KeyValueOfStringString>
	<KeyValueOfStringString xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:xsd="http://www.w3.org/2001/XMLSchema">
		<Key>00000100</Key>
		<Value>32769</Value>
	</KeyValueOfStringString>
	<KeyValueOfStringString xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:xsd="http://www.w3.org/2001/XMLSchema">
		<Key>00000120</Key>
		<Value>1</Value>
	</KeyValueOfStringString>
	<KeyValueOfStringString xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:xsd="http://www.w3.org/2001/XMLSchema">
		<Key>00000900</Key>
		<Value>0</Value>
	</KeyValueOfStringString>
	<KeyValueOfStringString xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:xsd="http://www.w3.org/2001/XMLSchema">
		<Key>00001000</Key>
		<Value>1.2.826.0.1.3680043.8.498.32716899523805676341314488233555003046</Value>
	</KeyValueOfStringString>
	<KeyValueOfStringString xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:xsd="http://www.w3.org/2001/XMLSchema">
		<Key>00000800</Key>
		<Value>257</Value>
	</KeyValueOfStringString>
</SerializableDictionary>